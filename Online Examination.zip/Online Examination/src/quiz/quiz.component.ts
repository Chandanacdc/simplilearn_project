import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { QuizService } from './quiz.service';
import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, Router } from "@angular/router";

@Component({
  selector: 'quiz',
  templateUrl: './quiz.component.html',
  styleUrls : ['./quiz.component.css']
})

export class QuizComponent implements OnInit{

    answerForm: FormGroup;
    errorMessage: any;
    result:any = [];
    name:string;
    questions:any=[];
    question:any=[];
    correctOption=['ng-model' , 'Google'];
    isDone:boolean=false;
    answers:any=[];

    constructor(private route : ActivatedRoute , private router : Router ,private fb : FormBuilder , private quizService : QuizService){}

    ngOnInit(): void {

        this.name = this.route.snapshot.paramMap.get('name'); 
        console.log(name);
        
        this.quizService.getQuestions().subscribe(
            question =>{
                this.questions = question;
                console.log(this.questions);
            },
            error => {
                this.errorMessage = error,
                console.log(this.errorMessage)
            }
        );

        this.answerForm = this.fb.group({
        
                answer0 : [''],
                answer1 : ['']
            
        })

    }

    submit(){

        console.log("submit method called")
        console.log(this.answerForm.value);

        for (let i = 0; i < 2 ;  i++) {
            
            this.question.push(this.questions[i].question);

            if( this.correctOption[i] == this.answerForm.get('answer'+i).value ){
                    console.log('Matched Correct')
                    this.result.push(true);
                    this.answers.push(this.answerForm.get('answer'+i).value);

            }else if( ( this.answerForm.get('answer'+i).value == "" ) ){
                    console.log("Not Selected");
                    this.result[i] = false;
                    this.answers.push("Not Selected");  

            }else if( this.correctOption[i] != this.answerForm.get('answer'+i).value ){
                    console.log('Matched Wrong')
                    this.result[i] = false;
                    this.answers.push(this.answerForm.get('answer'+i).value);
                    
            }else{
                    console.log('Matched Nothing')
                    this.result[i] = "Nothing";
            }

        }

        console.log(this.result);
        this.isDone= true;
    }

}
